# Jarvis Android (MVP)

Türkçe erkek sesli, Android telefonda temel işlemleri kontrol edebilen bir Jarvis benzeri asistan için teslim paketi.

## Özellikler
- Türkçe sesli komut alma
- Türkçe erkek sesiyle yanıt verme
- Temel işlemler:
  - uygulama açma
  - alarm kurma
  - telefon araması başlatma
  - SMS ekranını açma
  - not alma
  - hava durumu sorgusu için web araması açma
- Komut geçmişi ekranı
- Mikrofon butonu ile konuşma

## Neden APK yok?
Bu çalışma alanında doğrudan Android build araçları ve imzalama zinciri olmadığı için gerçek APK derlenemiyor. Ama sana:
1. Hazır Android Studio projesi
2. Tek tıkta açılabilir kaynak kod
3. APK üretmek için net kurulum adımları
veriyorum.

İstersen sonraki adımda bunu gerçek APK'ye dönüştürmek için release adımlarını da ekleyebilirim.

## Proje yapısı
- `app/src/main/java/com/example/jarvis/MainActivity.kt`
- `app/src/main/java/com/example/jarvis/JarvisIntentHandler.kt`
- `app/src/main/java/com/example/jarvis/SpeechController.kt`
- `app/src/main/AndroidManifest.xml`
- `app/build.gradle.kts`
- `build.gradle.kts`
- `settings.gradle.kts`

## Android Studio ile çalıştırma
1. Android Studio aç
2. `jarvis-android` klasörünü aç
3. Gradle sync yap
4. Mikrofon iznini ver
5. Fiziksel Android cihazda çalıştır

## Notlar
- Android sürümüne göre bazı sistem ayarları doğrudan değiştirilemez; bu yüzden bazı işlemler ilgili ayar ekranını açar.
- Google Speech Recognizer ve Android TextToSpeech kullanılır.
- Tam ekran sürekli dinleyen offline Jarvis için sonraki sürümde foreground service + Vosk/Whisper entegrasyonu eklenebilir.

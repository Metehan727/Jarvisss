package com.example.jarvis

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.Settings
import android.widget.Toast
import java.util.Locale

class JarvisIntentHandler(private val context: Context) {

    fun handle(command: String): String {
        val text = command.lowercase(Locale("tr", "TR")).trim()

        return when {
            text.startsWith("arama yap") || text.startsWith("ara ") -> handleCall(text)
            text.startsWith("mesaj gönder") || text.startsWith("sms gönder") -> handleSms(text)
            text.contains("alarm kur") -> handleAlarm(text)
            text.startsWith("not al") || text.startsWith("not et") -> handleNote(text)
            text.startsWith("uygulama aç") || text.startsWith("aç ") -> handleAppLaunch(text)
            text.contains("wifi") -> openSettings("Wi‑Fi ayarları açılıyor", Settings.ACTION_WIFI_SETTINGS)
            text.contains("bluetooth") -> openSettings("Bluetooth ayarları açılıyor", Settings.ACTION_BLUETOOTH_SETTINGS)
            text.contains("parlaklık") -> openSettings("Ekran ayarları açılıyor", Settings.ACTION_DISPLAY_SETTINGS)
            text.contains("ses seviyesi") || text.contains("ses ayarı") -> openSettings("Ses ayarları açılıyor", Settings.ACTION_SOUND_SETTINGS)
            text.contains("el feneri") -> "El fenerini doğrudan kontrol etmek için sonraki sürümde kamera entegrasyonu eklenebilir."
            text.contains("hava durumu") -> handleWeather()
            else -> "Bu komutu henüz anlayamadım. Örneğin uygulama aç, alarm kur, ara, mesaj gönder veya not al diyebilirsin."
        }
    }

    private fun handleCall(text: String): String {
        val target = text
            .removePrefix("arama yap")
            .removePrefix("ara")
            .trim()

        if (target.isBlank()) return "Kimi aramamı istediğini söylemelisin."

        val intent = Intent(Intent.ACTION_DIAL).apply {
            data = Uri.parse("tel:${Uri.encode(target)}")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return "$target için arama ekranını açtım."
    }

    private fun handleSms(text: String): String {
        val body = text
            .removePrefix("mesaj gönder")
            .removePrefix("sms gönder")
            .trim()

        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:")
            putExtra("sms_body", body)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return "SMS ekranını açtım. Mesaj metnini düzenleyebilirsin."
    }

    private fun handleAlarm(text: String): String {
        val hourRegex = Regex("(\\d{1,2})[:.](\\d{1,2})")
        val match = hourRegex.find(text)
        val hour = match?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 7
        val minute = match?.groupValues?.getOrNull(2)?.toIntOrNull() ?: 0

        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, "Jarvis alarmı")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return String.format(Locale("tr", "TR"), "Alarmı %02d:%02d için hazırladım.", hour, minute)
    }

    private fun handleNote(text: String): String {
        val note = text
            .removePrefix("not al")
            .removePrefix("not et")
            .trim()

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, note.ifBlank { "Yeni not" })
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        return try {
            val chooser = Intent.createChooser(intent, "Notu paylaş veya kaydet").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
            "Not metnini paylaşım ekranına aktardım."
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(context, note, Toast.LENGTH_LONG).show()
            "Notu gösterdim."
        }
    }

    private fun handleAppLaunch(text: String): String {
        val appName = text
            .removePrefix("uygulama aç")
            .removePrefix("aç")
            .trim()

        if (appName.isBlank()) return "Hangi uygulamayı açmamı istediğini söylemelisin."

        val pm = context.packageManager
        val apps = pm.getInstalledApplications(0)
        val matched = apps.firstOrNull {
            pm.getApplicationLabel(it).toString().lowercase(Locale("tr", "TR")).contains(appName)
        }

        if (matched != null) {
            val launchIntent = pm.getLaunchIntentForPackage(matched.packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                return "${pm.getApplicationLabel(matched)} açılıyor."
            }
        }

        return "Bu uygulamayı bulamadım: $appName"
    }

    private fun handleWeather(): String {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=hava+durumu"))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return "Hava durumu sonucu açılıyor."
    }

    private fun openSettings(message: String, action: String): String {
        val intent = Intent(action).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
        context.startActivity(intent)
        return message
    }
}

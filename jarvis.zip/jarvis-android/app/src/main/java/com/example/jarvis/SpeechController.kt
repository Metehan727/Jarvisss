package com.example.jarvis

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

class SpeechController(context: Context) {
    private var tts: TextToSpeech? = null
    private var ready = false

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("tr", "TR")
                ready = true
            }
        }
    }

    fun speak(text: String) {
        if (ready) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_tts")
        }
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}

package com.example.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var speechController: SpeechController
    private lateinit var intentHandler: JarvisIntentHandler
    private var recognizer: SpeechRecognizer? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            speechController.speak("Mikrofon izni verildi. Hazırım efendim.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        speechController = SpeechController(this)
        intentHandler = JarvisIntentHandler(this)
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }

        setContent {
            MaterialTheme {
                JarvisApp(
                    onListen = { startListening(it) },
                    onSpeak = { speechController.speak(it) }
                )
            }
        }
    }

    private fun startListening(onResult: (String, String) -> Unit) {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Dinliyorum")
        }

        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = Unit
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = Unit
            override fun onError(error: Int) {
                onResult("", "Seni duyamadım veya tanıma başarısız oldu.")
                speechController.speak("Seni duyamadım.")
            }
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val spoken = matches?.firstOrNull().orEmpty()
                val reply = intentHandler.handle(spoken)
                onResult(spoken, reply)
                speechController.speak(reply)
            }
            override fun onPartialResults(partialResults: Bundle?) = Unit
            override fun onEvent(eventType: Int, params: Bundle?) = Unit
        })

        recognizer?.startListening(intent)
    }

    override fun onDestroy() {
        recognizer?.destroy()
        speechController.shutdown()
        super.onDestroy()
    }
}

@Composable
fun JarvisApp(
    onListen: ((String, String) -> Unit) -> Unit,
    onSpeak: (String) -> Unit
) {
    val history = remember { mutableStateListOf<Pair<String, String>>() }
    var status by remember { mutableStateOf("Hazırım efendim.") }

    LaunchedEffect(Unit) {
        onSpeak("Jarvis başlatıldı. Hazırım efendim.")
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Jarvis") })
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    status = "Dinliyorum..."
                    onListen { userText, reply ->
                        if (userText.isNotBlank()) {
                            history.add(0, userText to reply)
                        }
                        status = reply
                    }
                },
                containerColor = Color(0xFF00B7FF),
                contentColor = Color.Black,
                shape = CircleShape
            ) {
                Icon(Icons.Default.Mic, contentDescription = "Dinle")
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFF08111F), Color(0xFF0E2238), Color(0xFF05080D))
                    )
                )
                .padding(padding)
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0x2217C0FF)),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text("JARVIS", color = Color(0xFF7FDBFF), fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(status, color = Color.White, style = MaterialTheme.typography.headlineSmall)
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { onSpeak("Hazırım efendim.") }) {
                                Text("Kendini tanıt")
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Text("Komut Geçmişi", color = Color.White, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(history) { item ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0x1FFFFFFF)),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text("Sen: ${item.first}", color = Color(0xFF9FE8FF))
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Jarvis: ${item.second}", color = Color.White)
                            }
                        }
                    }
                }
            }

            if (history.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "Mikrofona bas ve örneğin\n'uygulama aç whatsapp'\n'veya'\n'alarm kur 07:30' de.",
                        color = Color(0xFFB7C9D6)
                    )
                }
            }
        }
    }
}
